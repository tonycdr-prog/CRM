import FieldTesting from "../../pages/field-testing";

export default function FieldTestingExample() {
  return <FieldTesting />;
}
